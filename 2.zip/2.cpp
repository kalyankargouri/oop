#include<iostream>

using namespace std;
int main()
{
    // int a=5,b=6,c=10;
    int a,b,c;
    cout <<"enter three numbers :";
    
    
    cin>>a>>b>>c;
    
    if(a> b && a>c)
    {
    cout<<"the largest number is :"<<a;
    // float
    }
    else if(b>a && b>c)
    {
          cout<<"the largest number is: "<<b; 
    }
    else{
        cout<<"the largest number is:"<<c;
    }
    
    return 0;
}
