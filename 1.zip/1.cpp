#include<iostream>

using namespace std;
int main()
{
    int a=5,b=6;
    // float;
    cout<<"the addition is:"<<a+b;
   
    cout<<"\n the subtraction is:"<<a-b;
    cout<<"\n the multification is:"<<a*b;
    cout<<"\n the division is :"<<(float)a/b;
    cout<<"\n the  modulus is:"<<a%b;
    // cout<<"the addition is:"<<a+b;
    return 0;
}
